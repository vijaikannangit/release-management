# Learning Git Hub Actions. 
> !Learning never exhausts mind !
> 
**Workflow-Actions-YAML**

Action Steps are:

```
Step 1 - Signup and Login to GitHub.com 
Step 2 - Create a new Repository 
Step 3 - In the repo create a folder .github/workflows 
Step 4 - In the folder create a YAML file with .yml extension 
Step 5 - Add the content of the workflow in the file 
Step 6 - Commit and push the changes 
Step 7 - Goto Repo main page and click “Actions” tab 
Step 8 - Select the workflow from left sidebar and check the logs and results
```

This was to view whether link been displayed :- [GitHub Pages](https://pages.github.com/).


Just tried writing Readme.md with emojis  :+1:   :desktop_computer:

## To Display Images
![Screenshot of a comment on a GitHub issue showing an image, added in the Markdown, of an Octocat smiling and raising a tentacle.](https://myoctocat.com/assets/images/base-octocat.svg)

